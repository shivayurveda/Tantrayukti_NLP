"""Shared helpers for the tantrayukti sentence-classification experiments.

Paper: "Tantrayukti-Based Analysis of the Tarkasaṅgraha: From Conceptual
Interpretation to Computational Classification".
All experiments use scikit-learn; random seed 42 unless stated otherwise.
"""
import os, re, warnings
import numpy as np
import pandas as pd
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.svm import LinearSVC
from sklearn.pipeline import make_pipeline
from sklearn.dummy import DummyClassifier
from sklearn.metrics import accuracy_score, f1_score

warnings.filterwarnings("ignore")
ROOT = os.path.dirname(os.path.abspath(__file__))
DATA = os.path.join(ROOT, "data")
RES = os.path.join(ROOT, "results")
FIG = os.path.join(ROOT, "figures")
for d in (RES, FIG):
    os.makedirs(d, exist_ok=True)
SEED = 42

# Labels excluded from predictive evaluation on the Tarkasaṅgraha (singletons)
SINGLETONS = ["prayojana", "samuccaya"]
# Labels shared by both texts and used in the cross-text test.
# prayojana is dropped (one Tarkasaṅgraha example); uddeśa (lakṣyam) is merged into uddeśa.
SHARED9 = ["padārtha", "nidarśana", "nirdeśa", "vyākhyāna", "uddeśa",
           "svasaṃjñā", "apadeśa", "ekānta", "nirṇaya"]


def load_ts():
    """Tarkasaṅgraha: 338 unique labelled sentences, 13 categories."""
    return pd.read_csv(os.path.join(DATA, "tarkasangraha_sentences.csv"))


def load_vs():
    """Vedāntasāra: 287 unique labelled sentences, 22 categories."""
    return pd.read_csv(os.path.join(DATA, "vedantasara_sentences.csv"))


def ts_eval11():
    """336 sentences, 11 categories (singletons removed); uddeśa (lakṣyam) kept separate."""
    d = load_ts()
    return d[~d.label.isin(SINGLETONS)].reset_index(drop=True)


def shared9(d):
    """Restrict to the nine shared labels; merge uddeśa (lakṣyam) into uddeśa."""
    d = d.copy()
    d["label"] = d.label.replace({"uddeśa (lakṣyam)": "uddeśa"})
    d["label_devanagari"] = d.label_devanagari.replace({"उद्देशः (लक्ष्यम्)": "उद्देशः"})
    return d[d.label.isin(SHARED9)].reset_index(drop=True)


def make_vectorizer(kind, **kw):
    if kind == "char":      # character n-grams 3-5
        p = dict(analyzer="char", ngram_range=(3, 5)); p.update(kw)
        return TfidfVectorizer(**p)
    if kind == "word":      # whitespace tokens, word 1-2-grams
        p = dict(analyzer="word", token_pattern=r"\S+", ngram_range=(1, 2), lowercase=False); p.update(kw)
        return TfidfVectorizer(**p)
    raise ValueError(kind)


def make_model(kind, C=1.0, class_weight=None, **vkw):
    """Vectoriser + LinearSVC; kind in {'char','word','majority'}."""
    if kind == "majority":
        return DummyClassifier(strategy="most_frequent")
    return make_pipeline(make_vectorizer(kind, **vkw), LinearSVC(C=C, class_weight=class_weight))


def scores(y, p):
    return (accuracy_score(y, p), f1_score(y, p, average="macro"), f1_score(y, p, average="weighted"))


def save(df, name, index=False):
    df.to_csv(os.path.join(RES, name), index=index)


def strat_key(d):
    """Key used for stratified splitting. The Devanagari label strings are used (not the IAST names)
    because scikit-learn's stratified splitters allocate samples in sorted-class order, so the key
    determines the exact splits; this reproduces the splits reported in the paper."""
    return d.label_devanagari.values
