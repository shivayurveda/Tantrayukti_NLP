"""Build the two sentence-level CSVs from the annotation workbooks.

Usage: python 00_prepare_data.py Tarka_sangraha_moola.xlsx Vedanta-saara.xlsx
(The CSVs are already included in data/, so this step is only needed to rebuild them.)
Text is stripped of leading/trailing whitespace; rows need a non-empty sentence and a
primary tantrayukti label other than blank or '-'; exact-text duplicates are removed.
"""
import re, sys, json
import pandas as pd
from common import DATA
import os

IAST = {  # Devanagari tag -> IAST label used in the paper
 "पदार्थः": "padārtha", "निदर्शनम्/दृष्टान्तः": "nidarśana", "निर्देशः": "nirdeśa",
 "व्याख्यानम्": "vyākhyāna", "उद्देशः": "uddeśa", "उद्देशः (लक्ष्यम्)": "uddeśa (lakṣyam)",
 "स्वसंज्ञा": "svasaṃjñā", "अपदेशः/हेत्वर्थः": "apadeśa", "एकान्तः": "ekānta",
 "निर्णयः": "nirṇaya", "योगः": "yoga", "प्रयोजनम्": "prayojana", "समुच्चयः": "samuccaya",
 # labels that occur only in the Vedāntasāra
 "उपदेशः": "upadeśa", "उद्धारः": "uddhāra", "अधिकरणम्": "adhikaraṇa", "अनुमतम्": "anumata",
 "विकल्पः": "vikalpa", "अतिक्रान्तावेक्षणम्": "atikrāntāvekṣaṇa", "सम्भवः": "saṃbhava",
 "प्रसङ्गः": "prasaṅga", "पूर्वपक्षः": "pūrvapakṣa", "उत्तरपक्षः": "uttarapakṣa",
 "निर्वचनम्": "nirvacana", "ऊह्यम्": "ūhya"}

def dev_label(x):
    x = re.sub(r"\s+[A-Za-z].*$", "", str(x).strip()).strip()
    return x

def build(path, id_col, sent_col, lab_col):
    t = pd.read_excel(path, sheet_name="Vakyas")
    d = t[[id_col, sent_col, lab_col]].copy(); d.columns = ["sentence_id", "sentence", "raw"]
    n_rows = len(d)
    d = d[d.sentence.notna() & d.raw.notna()]
    d["sentence"] = d.sentence.astype(str).str.strip()
    d["label_devanagari"] = d.raw.map(dev_label)
    d = d[(d.label_devanagari != "-") & (d.label_devanagari != "")]
    n_usable = len(d)
    d = d.drop_duplicates("sentence").reset_index(drop=True)
    d["label"] = d.label_devanagari.map(IAST)
    assert d.label.notna().all(), d[d.label.isna()]
    return d[["sentence_id", "sentence", "label", "label_devanagari"]], dict(rows=n_rows, usable=n_usable, unique=len(d), categories=d.label.nunique())

if __name__ == "__main__":
    ts_path, vs_path = sys.argv[1], sys.argv[2]
    ts, s1 = build(ts_path, "Vakya_id", "Vakya वाक्यम्", "Tantrayukti_tag वाक्य-स्तरे (तन्त्रयुक्तिः)")
    vs, s2 = build(vs_path, "Vakya_id", "Vakya वाक्यम्", "Tantrayukti_tag वाक्य-स्तरे (तन्त्रयुक्तिः)")
    ts.to_csv(os.path.join(DATA, "tarkasangraha_sentences.csv"), index=False)
    vs.to_csv(os.path.join(DATA, "vedantasara_sentences.csv"), index=False)
    json.dump({"tarkasangraha": s1, "vedantasara": s2}, open(os.path.join(DATA, "dataset_summary.json"), "w"), indent=1)
    print(s1, s2)
