"""Table 8 and Section 4.5: near-duplicate analysis and surface-cue ablations (Tarkasaṅgraha, 336 sentences)."""
import re, string
from scipy.sparse import csr_matrix
from scipy.sparse.csgraph import connected_components
from sklearn.model_selection import RepeatedStratifiedKFold, StratifiedGroupKFold
from common import *

d = ts_eval11(); X, y, key = d.sentence.values, d.label.values, strat_key(d)
V = make_vectorizer("char").fit_transform(X); S = (V @ V.T).toarray(); np.fill_diagonal(S, 0)
nn, nnj = S.max(1), S.argmax(1)
lines = []
for t in (0.7, 0.8, 0.9):
    idx = np.where(nn >= t)[0]
    same = np.mean([y[i] == y[nnj[i]] for i in idx]) if len(idx) else float("nan")
    lines.append(f"cosine>={t}: {len(idx)} sentences have a neighbour; same label share={same:.2f}")

def clusters(t):
    return connected_components(csr_matrix(S >= t), directed=False)

# ---- near-duplicates inside the standard repeated CV (test sentence has a >=0.8 neighbour in the training fold)
cv = list(RepeatedStratifiedKFold(n_splits=3, n_repeats=10, random_state=SEED).split(X, key))
hit, ok_hit, miss, ok_miss = 0, 0, 0, 0
for tr, te in cv:
    p = make_model("char").fit(X[tr], y[tr]).predict(X[te])
    has = S[np.ix_(te, tr)].max(1) >= 0.8
    hit += has.sum(); ok_hit += ((p == y[te]) & has).sum(); miss += (~has).sum(); ok_miss += ((p == y[te]) & ~has).sum()
lines.append(f"CV test sentences with a >=0.8 neighbour in training fold: {hit}/{hit+miss} ({100*hit/(hit+miss):.1f}%); "
             f"accuracy on them={100*ok_hit/max(hit,1):.1f}%, on the rest={100*ok_miss/miss:.1f}% (n={miss})")

def summarise(rows):
    out = {}
    for k in ("char", "word"):
        a = np.array(rows[k]); out[k] = (100 * a[:, 0].mean(), a[:, 1].mean())
    return out

def run_cv(Xv):
    rows = {"char": [], "word": []}
    for tr, te in cv:
        for k in rows:
            rows[k].append(scores(y[te], make_model(k).fit(Xv[tr], y[tr]).predict(Xv[te])))
    return summarise(rows)

def run_grouped(t):
    n, g = clusters(t); rows = {"char": [], "word": []}
    for r in range(10):
        for tr, te in StratifiedGroupKFold(n_splits=3, shuffle=True, random_state=r).split(X, key, g):
            for k in rows:
                rows[k].append(scores(y[te], make_model(k).fit(X[tr], y[tr]).predict(X[te])))
    return summarise(rows), n

# ---- surface cues
DIG = lambda s: re.sub(r"[0-9०-९]+", "", s).strip()                          # verse numbers (ASCII + Devanagari digits)
PUN = lambda s: re.sub(r"[।॥|" + re.escape(string.punctuation) + r"]", "", s).strip()   # daṇḍas, verse-line marks, ASCII punctuation
lines.append("sentences containing digits: %.1f%%" % (100 * np.mean([bool(re.search(r"[0-9०-९]", s)) for s in X])))
lines.append("sentences ending in a daṇḍa or double daṇḍa: %.1f%%" % (100 * np.mean([s.rstrip()[-1] in "।॥" for s in X])))

tab = [["Original (Table 6)"] + [round(v, 4) if i % 2 else round(v, 2) for k in ("char", "word") for i, v in enumerate(run_cv(X)[k])]]
for t in (0.8, 0.7):
    r, n = run_grouped(t); lines.append(f"clusters at cosine>={t}: {n}")
    tab.append([f"Grouped, cosine ≥ {t}"] + [round(v, 4) if i % 2 else round(v, 2) for k in ("char", "word") for i, v in enumerate(r[k])])
for name, f in [("Digits removed", DIG), ("Punctuation removed", PUN), ("Digits and punctuation removed", lambda s: PUN(DIG(s)))]:
    r = run_cv(np.array([f(s) for s in X]))
    tab.append([name] + [round(v, 4) if i % 2 else round(v, 2) for k in ("char", "word") for i, v in enumerate(r[k])])
t8 = pd.DataFrame(tab, columns=["Condition", "Char acc. (%)", "Char macro-F1", "Word acc. (%)", "Word macro-F1"])
save(t8, "table8_robustness.csv"); print(t8.to_string(index=False))
open(os.path.join(RES, "robustness_notes.txt"), "w").write("\n".join(lines) + "\n"); print("\n".join(lines))
