# Code and data: sentence-level tantrayukti classification (Tarkasaṅgraha, Vedāntasāra)

Companion code for the paper *Beyond Word Boundaries: Sentence-Level Tantrayukti Classification in the
Tarkasaṅgraha and Its Limits Across Texts*. Running `./run_all.sh` regenerates every table and figure
(about 5–10 minutes on a laptop, no GPU).

## Contents

| File | Produces |
|---|---|
| `data/tarkasangraha_sentences.csv` | 338 unique labelled sentences, 13 categories (Devanagari text, IAST label) |
| `data/vedantasara_sentences.csv` | 287 unique labelled sentences, 22 categories |
| `data/dataset_summary.json` | Row counts at each filtering step (Table 2) |
| `00_prepare_data.py` | Rebuilds the two CSVs from the annotation workbooks (optional) |
| `common.py` | Loading, label sets, vectorisers, model factory |
| `01_main_experiments.py` | Table 5 (holdout), sign test, Table 6 (repeated CV), Table 7 (per-class), Figure 2 data |
| `02_robustness.py` | Table 8: near-duplicate grouping, digit and punctuation ablations |
| `03_multiseed_holdout.py` | Section 4.6: 30 holdout seeds |
| `04_nested_cv.py` | Table 9: nested CV, tuned and alternative models |
| `05_cross_text.py` | Tables 10–11, paired tests, bootstrap CIs, per-class cross-text results |
| `06_make_figures.py` | Figures 1–3 |
| `results/` | Output tables (CSV) and logs written by the scripts |
| `figures/` | Figures 1–3 (PNG, 300 dpi) |

## Setup

    pip install -r requirements.txt
    ./run_all.sh            # or run the numbered scripts one by one

## Method summary

* Text is stripped of leading and trailing whitespace; no other normalisation.
* Word features: whitespace tokens, 1–2-grams. Character features: 3–5-grams (`analyzer="char"`).
  Both use TF-IDF; the classifier is `LinearSVC(C=1)`; the baseline predicts the majority class.
* Predictive evaluation on the Tarkasaṅgraha uses 336 sentences and 11 categories (the singleton
  labels prayojana and samuccaya are excluded). Random seed 42 unless stated.
* Cross-text transfer uses the nine labels shared by both texts (prayojana dropped; uddeśa (lakṣyam)
  merged into uddeśa): 331 Tarkasaṅgraha and 227 Vedāntasāra sentences.
* Stratified splits use the Devanagari label string as the stratification key (`common.strat_key`),
  because scikit-learn's stratified splitters depend on the sorted class order. Using the IAST names
  would give different (equally valid) splits.

## Reproduction notes

Tables 5, 6 and 7, the sign test, the near-duplicate and grouped-CV results, the digit ablation, the
30-seed holdout results and the default rows of Table 9 are reproduced exactly. The following were
re-run with the settings documented in the scripts and are reported from this code:

* **Table 8, punctuation rows:** punctuation is defined as daṇḍa, double daṇḍa, `|` and ASCII
  punctuation.
* **Table 9, tuned and alternative rows:** the hyper-parameter grids are listed in `04_nested_cv.py`
  (inner 3-fold CV, macro-F1 selection).
* **Tables 10–11:** the cross-text analysis (new in this version).

## Data and licence

The CSVs contain the Sanskrit sentences of two classical texts and the primary tantrayukti label
assigned by the annotators. The labels are group-refined; no inter-annotator agreement was computed.
Add a licence for the labels and code (for example CC BY 4.0 for the data and MIT for the code)
before public release.
