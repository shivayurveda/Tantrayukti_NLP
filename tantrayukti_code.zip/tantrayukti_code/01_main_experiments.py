"""Tables 5-7 and Figure 2 data: stratified holdout, repeated CV, paired test, per-class results.
Evaluation set: Tarkasaṅgraha, 336 sentences, 11 categories."""
import numpy as np, pandas as pd
from scipy.stats import binomtest
from sklearn.model_selection import train_test_split, RepeatedStratifiedKFold
from sklearn.metrics import precision_recall_fscore_support, confusion_matrix
from common import *

d = ts_eval11(); X, y, key = d.sentence.values, d.label.values, strat_key(d)
labels = list(d.label.value_counts().index)            # frequency order (as in Table 7)

# ---- Protocol 1: stratified 80:20 holdout (Table 5) ----
Xtr, Xte, ytr, yte = train_test_split(X, y, test_size=0.2, stratify=key, random_state=SEED)
rows, pred = [], {}
for name, kind in [("Majority baseline", "majority"), ("Word TF-IDF + LinearSVC", "word"), ("Character TF-IDF + LinearSVC", "char")]:
    p = make_model(kind).fit(Xtr, ytr).predict(Xte); pred[kind] = p
    a, m, w = scores(yte, p); rows.append([name, round(100 * a, 2), round(m, 4), round(w, 4)])
save(pd.DataFrame(rows, columns=["Model", "Accuracy (%)", "Macro-F1", "Weighted-F1"]), "table5_holdout.csv")
print("Table 5 (train %d / test %d)" % (len(Xtr), len(Xte))); print(pd.DataFrame(rows).to_string(index=False))

# ---- Paired exact sign test on the holdout (Section 4.3) ----
c, w_ = pred["char"] == yte, pred["word"] == yte
a, b = int((c & ~w_).sum()), int((~c & w_).sum())
pval = binomtest(a, a + b, 0.5).pvalue
open(os.path.join(RES, "sign_test_holdout.txt"), "w").write(f"char-only correct={a}\nword-only correct={b}\np={pval:.3f}\n")
print("sign test: char-only %d, word-only %d, p=%.3f" % (a, b, pval))

# ---- Protocol 2: repeated stratified 3-fold CV, 10 repeats (Table 6) ----
cv = RepeatedStratifiedKFold(n_splits=3, n_repeats=10, random_state=SEED)
sc = {"word": [], "char": []}; pooled = {"word": [], "char": []}; truth = []
for tr, te in cv.split(X, key):
    truth.extend(y[te])
    for kind in ("word", "char"):
        p = make_model(kind).fit(X[tr], y[tr]).predict(X[te]); pooled[kind].extend(p); sc[kind].append(scores(y[te], p))
rows = []
for name, kind in [("Word TF-IDF + LinearSVC", "word"), ("Character TF-IDF + LinearSVC", "char")]:
    s = np.array(sc[kind]); mu, sd = s.mean(0), s.std(0, ddof=1)
    rows.append([name, f"{100*mu[0]:.2f} ({100*sd[0]:.2f})", f"{mu[1]:.4f} ({sd[1]:.4f})", f"{mu[2]:.4f} ({sd[2]:.4f})"])
save(pd.DataFrame(rows, columns=["Model", "Accuracy (%)", "Macro-F1", "Weighted-F1"]), "table6_repeated_cv.csv")
print("\nTable 6"); print(pd.DataFrame(rows).to_string(index=False))

# ---- Per-class results pooled over the 30 test folds (Table 7) ----
truth = np.array(truth); out = []
pr = {k: precision_recall_fscore_support(truth, np.array(pooled[k]), labels=labels, zero_division=0) for k in pooled}
for i, l in enumerate(labels):
    out.append([l, int((y == l).sum())] + [round(pr["char"][j][i], 2) for j in (0, 1, 2)] + [round(pr["word"][j][i], 2) for j in (0, 1, 2)])
t7 = pd.DataFrame(out, columns=["Class", "n", "Char P", "Char R", "Char F1", "Word P", "Word R", "Word F1"])
save(t7, "table7_per_class.csv"); print("\nTable 7"); print(t7.to_string(index=False))

# ---- Confusion matrix (character-level), average count per CV pass (Figure 2) ----
cm = confusion_matrix(truth, np.array(pooled["char"]), labels=labels) / 10.0
save(pd.DataFrame(cm, index=labels, columns=labels), "confusion_char_avg_per_pass.csv", index=True)
