"""Section 4.8: cross-text transfer between the Tarkasaṅgraha and the Vedāntasāra on the nine shared labels
(Tables 10-11, paired tests, bootstrap confidence intervals, per-class results)."""
from scipy.stats import binomtest
from sklearn.model_selection import RepeatedStratifiedKFold
from sklearn.metrics import classification_report
from common import *

TS, VS = shared9(load_ts()), shared9(load_vs())
print("shared-label sentences: Tarkasaṅgraha %d, Vedāntasāra %d" % (len(TS), len(VS)))

# ---- Table 10: label distribution ----
order = ["padārtha", "nidarśana", "nirdeśa", "vyākhyāna", "uddeśa", "svasaṃjñā", "apadeśa", "ekānta", "nirṇaya"]
rows = []
for l in order:
    a, b = (TS.label == l).sum(), (VS.label == l).sum()
    rows.append([l, f"{a} ({100*a/len(TS):.1f})", f"{b} ({100*b/len(VS):.1f})"])
rows.append(["Total", f"{len(TS)} (100)", f"{len(VS)} (100)"])
t10 = pd.DataFrame(rows, columns=["Label", "Tarkasaṅgraha", "Vedāntasāra"]); save(t10, "table10_shared_label_distribution.csv"); print(t10.to_string(index=False))

# ---- Table 11: cross-text transfer ----
def fit_pred(tr, te, kind):
    return make_model(kind).fit(tr.sentence.values, tr.label.values).predict(te.sentence.values)

res, preds = [], {}
for setting, tr, te in [("Train Tarkasaṅgraha → test Vedāntasāra", TS, VS), ("Train Vedāntasāra → test Tarkasaṅgraha", VS, TS)]:
    for name, kind in [("Majority baseline", "majority"), ("Word TF-IDF + LinearSVC", "word"), ("Character TF-IDF + LinearSVC", "char")]:
        p = fit_pred(tr, te, kind); preds[(setting, kind)] = p
        a, m, w = scores(te.label.values, p)
        res.append([setting, name, f"{100*a:.2f}", f"{m:.4f}", f"{w:.4f}"])
for tname, D in (("Tarkasaṅgraha", TS), ("Vedāntasāra", VS)):
    X, y, key = D.sentence.values, D.label.values, strat_key(D)
    cv = list(RepeatedStratifiedKFold(n_splits=3, n_repeats=10, random_state=SEED).split(X, key))
    for name, kind in [("Word TF-IDF + LinearSVC", "word"), ("Character TF-IDF + LinearSVC", "char")]:
        a = np.array([scores(y[te], make_model(kind).fit(X[tr], y[tr]).predict(X[te])) for tr, te in cv])
        res.append([f"Within {tname} (CV, 9 labels)", name, f"{100*a[:,0].mean():.2f} ({100*a[:,0].std(ddof=1):.2f})", f"{a[:,1].mean():.4f}", f"{a[:,2].mean():.4f}"])
t11 = pd.DataFrame(res, columns=["Setting", "Model", "Accuracy (%)", "Macro-F1", "Weighted-F1"]); save(t11, "table11_cross_text.csv"); print(t11.to_string(index=False))

# ---- paired sign test + bootstrap CI for the char-vs-word accuracy difference ----
rng = np.random.default_rng(0); lines = []
for setting, te in [("Train Tarkasaṅgraha → test Vedāntasāra", VS), ("Train Vedāntasāra → test Tarkasaṅgraha", TS)]:
    y = te.label.values; c = preds[(setting, "char")] == y; w = preds[(setting, "word")] == y
    a, b = int((c & ~w).sum()), int((~c & w).sum()); p = binomtest(a, a + b, 0.5).pvalue if a + b else 1.0
    gaps = [c[i].mean() - w[i].mean() for i in (rng.integers(0, len(y), len(y)) for _ in range(2000))]
    lo, hi = np.percentile(gaps, [2.5, 97.5])
    lines.append(f"{setting}: char-only correct={a}, word-only correct={b}, exact sign test p={p:.4g}; "
                 f"accuracy difference char-word={100*(c.mean()-w.mean()):+.2f} points, bootstrap 95% CI [{100*lo:+.1f}, {100*hi:+.1f}]")
open(os.path.join(RES, "cross_text_tests.txt"), "w").write("\n".join(lines) + "\n"); print("\n".join(lines))

# ---- per-class results (character-level) ----
pc = []
for setting, te in [("TS→VS", VS), ("VS→TS", TS)]:
    key = "Train Tarkasaṅgraha → test Vedāntasāra" if setting == "TS→VS" else "Train Vedāntasāra → test Tarkasaṅgraha"
    r = classification_report(te.label.values, preds[(key, "char")], labels=order, output_dict=True, zero_division=0)
    for l in order: pc.append([setting, l, int(r[l]["support"]), round(r[l]["precision"], 2), round(r[l]["recall"], 2), round(r[l]["f1-score"], 2)])
t = pd.DataFrame(pc, columns=["direction", "label", "support", "precision", "recall", "f1"]); save(t, "cross_text_per_class_char.csv"); print(t.to_string(index=False))
