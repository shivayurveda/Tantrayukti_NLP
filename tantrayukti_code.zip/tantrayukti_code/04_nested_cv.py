"""Table 9 / Section 4.7: nested cross-validation for tuned and alternative models.
Outer loop: repeated stratified 3-fold CV, 3 repeats (random_state=42) -> 9 test folds.
Inner loop: stratified 3-fold (shuffled, random_state=42), selection on macro-F1.
Default rows (untuned) use the Table 4 settings."""
from sklearn.model_selection import RepeatedStratifiedKFold, StratifiedKFold, GridSearchCV
from sklearn.pipeline import Pipeline, FeatureUnion
from sklearn.linear_model import LogisticRegression
from sklearn.naive_bayes import ComplementNB
from common import *

d = ts_eval11(); X, y, key = d.sentence.values, d.label.values, strat_key(d)
outer = list(RepeatedStratifiedKFold(n_splits=3, n_repeats=3, random_state=SEED).split(X, key))
inner = StratifiedKFold(3, shuffle=True, random_state=SEED)
CW = [None, "balanced"]
chv = lambda: make_vectorizer("char"); wdv = lambda: make_vectorizer("word")
SPECS = {
 "Character TF-IDF + LinearSVC (default: 3–5, C=1)": ("default", "char"),
 "Character TF-IDF + LinearSVC (tuned: n-gram, C, class weight)": (
    Pipeline([("v", chv()), ("c", LinearSVC())]),
    {"v__ngram_range": [(2, 4), (3, 5), (3, 6)], "c__C": [0.1, 1, 10], "c__class_weight": CW}),
 "Word TF-IDF + LinearSVC (default: 1–2, C=1)": ("default", "word"),
 "Word TF-IDF + LinearSVC (tuned: n-gram, C, class weight)": (
    Pipeline([("v", wdv()), ("c", LinearSVC())]),
    {"v__ngram_range": [(1, 1), (1, 2), (1, 3)], "c__C": [0.1, 1, 10], "c__class_weight": CW}),
 "Word + character TF-IDF + LinearSVC (tuned: C, class weight)": (
    Pipeline([("v", FeatureUnion([("w", wdv()), ("c", chv())])), ("c", LinearSVC())]),
    {"c__C": [0.1, 1, 10], "c__class_weight": CW}),
 "Character TF-IDF + logistic regression (tuned: C, class weight)": (
    Pipeline([("v", chv()), ("c", LogisticRegression(max_iter=3000))]),
    {"c__C": [1, 10, 100], "c__class_weight": CW}),
 "Character TF-IDF + Complement NB (tuned: alpha)": (
    Pipeline([("v", chv()), ("c", ComplementNB())]),
    {"c__alpha": [0.01, 0.03, 0.1, 0.3, 1.0]}),
}
rows, chosen = [], {}
for name, (est, grid) in SPECS.items():
    sc, sel = [], []
    for tr, te in outer:
        if est == "default":
            m = make_model(grid).fit(X[tr], y[tr])
        else:
            m = GridSearchCV(est, grid, scoring="f1_macro", cv=inner, n_jobs=-1).fit(X[tr], y[tr]); sel.append(m.best_params_)
        sc.append(scores(y[te], m.predict(X[te])))
    a = np.array(sc)
    rows.append([name, f"{100*a[:,0].mean():.2f} ({100*a[:,0].std(ddof=1):.2f})", f"{a[:,1].mean():.4f} ({a[:,1].std(ddof=1):.4f})", f"{a[:,2].mean():.4f} ({a[:,2].std(ddof=1):.4f})"])
    chosen[name] = sel; print(rows[-1], flush=True)
t9 = pd.DataFrame(rows, columns=["Model", "Accuracy (%)", "Macro-F1", "Weighted-F1"])
save(t9, "table9_nested_cv.csv")
with open(os.path.join(RES, "nested_cv_selected_params.txt"), "w") as f:
    for k, v in chosen.items():
        if v:
            bal = sum(p.get("c__class_weight") == "balanced" for p in v)
            f.write(f"{k}\n  class_weight='balanced' chosen in {bal}/{len(v)} outer folds\n  " + "\n  ".join(map(str, v)) + "\n")
print(t9.to_string(index=False))
