"""Section 4.6: stratified 80:20 holdout repeated over seeds 0-29 (Tarkasaṅgraha, 336 sentences)."""
from sklearn.model_selection import train_test_split
from common import *

d = ts_eval11(); X, y, key = d.sentence.values, d.label.values, strat_key(d)
R = {"majority": [], "word": [], "char": []}
for seed in range(30):
    tr, te = train_test_split(np.arange(len(y)), test_size=0.2, stratify=key, random_state=seed)
    for k in R:
        R[k].append(scores(y[te], make_model(k).fit(X[tr], y[tr]).predict(X[te])))
A = {k: np.array(v) for k, v in R.items()}
rows = [[k, round(100 * A[k][:, 0].mean(), 2), round(100 * A[k][:, 0].std(ddof=1), 2), round(100 * A[k][:, 0].min(), 1), round(100 * A[k][:, 0].max(), 1),
         round(A[k][:, 1].mean(), 4), round(A[k][:, 1].std(ddof=1), 4), round(A[k][:, 2].mean(), 4)] for k in A]
t = pd.DataFrame(rows, columns=["model", "acc_mean", "acc_sd", "acc_min", "acc_max", "macroF1_mean", "macroF1_sd", "weightedF1_mean"])
save(t, "multiseed_holdout.csv"); print(t.to_string(index=False))
ca, wa = A["char"][:, 0], A["word"][:, 0]
msg = f"char > word accuracy on {(ca>wa).sum()}/30 splits, tie {(ca==wa).sum()}, word > char {(ca<wa).sum()}; macro-F1 char > word on {(A['char'][:,1]>A['word'][:,1]).sum()}/30"
open(os.path.join(RES, "multiseed_counts.txt"), "w").write(msg + "\n"); print(msg)
