"""Figures 1-3 of the paper (PNG, 300 dpi).  Run after 01 and 05 (reads results/*.csv)."""
import textwrap
import matplotlib; matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch
from common import *

plt.rcParams.update({"font.family": "serif", "font.serif": ["DejaVu Serif"], "axes.unicode_minus": False})

# ------------------------------------------------------------------ Figure 1: workflow
def fig1():
    fig, ax = plt.subplots(figsize=(7.4, 5.8)); ax.set_xlim(0, 100); ax.set_ylim(0, 82); ax.axis("off")
    cols = {"A": "#dbe9f6", "B": "#e3f1e0", "C": "#fbe8d0"}
    X = [1, 27, 53, 79]; W = 20; H = 18
    def box(x, y, txt, c):
        ax.add_patch(FancyBboxPatch((x, y), W, H, boxstyle="round,pad=0.25,rounding_size=1.2", fc=c, ec="#333333", lw=0.8))
        head, body = txt.split("\n", 1)
        ax.text(x + W / 2, y + H - 1.8, head, ha="center", va="top", fontsize=7.0, fontweight="bold")
        ax.text(x + W / 2, y + H - 5.6, textwrap.fill(body, 23), ha="center", va="top", fontsize=6.6, linespacing=1.3)
    def arrow(x1, y1, x2, y2):
        ax.annotate("", xy=(x2, y2), xytext=(x1, y1), arrowprops=dict(arrowstyle="-|>", color="#333333", lw=1.0, shrinkA=0, shrinkB=0))
    def panel(label, y, boxes, col, rtl=False):
        ax.text(1, y + H + 2.4, label, fontsize=8.6, fontweight="bold", ha="left", va="bottom")
        pos = X[::-1] if rtl else X
        for x, t in zip(pos, boxes): box(x, y, t, col)
        for i in range(3):
            if rtl: arrow(pos[i] - 0.5, y + H / 2, pos[i + 1] + W + 0.5, y + H / 2)
            else: arrow(pos[i] + W + 0.5, y + H / 2, pos[i + 1] - 0.5, y + H / 2)
    panel("A   Dataset preparation (Tarkasaṅgraha)", 59, [
        "Source worksheet\n354 rows",
        "Usable rows\n340 rows with sentence text and a primary label",
        "Deduplication\n338 unique sentences, 13 categories",
        "Predictive subset\n336 sentences, 11 categories (2 singleton labels removed)"], cols["A"])
    panel("B   Within-text evaluation (read right to left)", 31, [
        "Data splits\nStratified 80:20 holdout (268 / 68); repeated stratified 3-fold CV (10 repeats)",
        "Features\nWord TF-IDF (1–2-grams); character TF-IDF (3–5-grams)",
        "Classifiers\nLinearSVC (C = 1); majority-class baseline",
        "Metrics\nAccuracy, macro-F1, weighted-F1; sign test; robustness checks"], cols["B"], rtl=True)
    arrow(89, 59 - 0.5, 89, 31 + H + 0.5)
    panel("C   Cross-text transfer (Tarkasaṅgraha and Vedāntasāra)", 3, [
        "Two annotated texts\nTarkasaṅgraha: 338 sentences; Vedāntasāra: 287 sentences",
        "Shared-label subset\n9 shared labels: 331 and 227 sentences",
        "Transfer test\nTrain on one text, test on the other, in both directions",
        "Metrics\nAccuracy, macro-F1, weighted-F1; sign test; bootstrap 95% CI"], cols["C"])
    fig.savefig(os.path.join(FIG, "figure1_workflow.png"), dpi=300, bbox_inches="tight", facecolor="white"); plt.close(fig)

# ------------------------------------------------------------------ Figure 2: confusion matrix (character-level)
def fig2():
    cm = pd.read_csv(os.path.join(RES, "confusion_char_avg_per_pass.csv"), index_col=0)
    labels = list(cm.index); M = cm.values; share = M / M.sum(1, keepdims=True)
    fig, ax = plt.subplots(figsize=(7.2, 6.2))
    im = ax.imshow(share, cmap="Blues", vmin=0, vmax=1)
    ax.set_xticks(range(len(labels))); ax.set_xticklabels(labels, rotation=45, ha="right", fontsize=8)
    ax.set_yticks(range(len(labels))); ax.set_yticklabels(labels, fontsize=8)
    ax.set_xlabel("Predicted label", fontsize=9); ax.set_ylabel("Reference label", fontsize=9)
    for i in range(len(labels)):
        for j in range(len(labels)):
            if M[i, j] >= 0.5:   # cells averaging under 0.5 per pass are left unlabelled
                ax.text(j, i, f"{M[i, j]:.0f}", ha="center", va="center", fontsize=7, color="white" if share[i, j] > 0.5 else "black")
    cb = fig.colorbar(im, ax=ax, fraction=0.046, pad=0.03); cb.set_label("Share of reference class", fontsize=8); cb.ax.tick_params(labelsize=7)
    fig.tight_layout(); fig.savefig(os.path.join(FIG, "figure2_confusion_char.png"), dpi=300, facecolor="white"); plt.close(fig)

# ------------------------------------------------------------------ Figure 3: cross-text accuracy
def fig3():
    t = pd.read_csv(os.path.join(RES, "table11_cross_text.csv"))
    def val(setting_prefix, model_prefix):
        r = t[t.Setting.str.startswith(setting_prefix) & t.Model.str.startswith(model_prefix)].iloc[0]
        s = str(r["Accuracy (%)"]); v = float(s.split()[0]); sd = float(s.split("(")[1].rstrip(")")) if "(" in s else 0.0
        return v, sd
    groups = [("Within Tarkasaṅgraha\n(CV)", "Within Tarkasaṅgraha"), ("Within Vedāntasāra\n(CV)", "Within Vedāntasāra"),
              ("Train Tarkasaṅgraha\n→ test Vedāntasāra", "Train Tarkasaṅgraha"), ("Train Vedāntasāra\n→ test Tarkasaṅgraha", "Train Vedāntasāra")]
    # majority-class accuracy = share of the most frequent class in the evaluated text
    TS, VS = shared9(load_ts()), shared9(load_vs())
    maj = [TS.label.value_counts(normalize=True).iloc[0], VS.label.value_counts(normalize=True).iloc[0],
           VS.label.value_counts(normalize=True).iloc[0], TS.label.value_counts(normalize=True).iloc[0]]
    fig, ax = plt.subplots(figsize=(7.2, 3.9)); w = 0.26; xs = np.arange(4)
    series = [("Majority baseline", [100 * m for m in maj], [0] * 4, "#bdbdbd"),
              ("Word TF-IDF", [val(g[1], "Word")[0] for g in groups], [val(g[1], "Word")[1] for g in groups], "#6baed6"),
              ("Character TF-IDF", [val(g[1], "Character")[0] for g in groups], [val(g[1], "Character")[1] for g in groups], "#08519c")]
    for k, (name, v, sd, c) in enumerate(series):
        xk = xs + (k - 1) * w
        ax.bar(xk, v, w, label=name, color=c, ec="#333333", lw=0.6)
        for xi, vi, si in zip(xk, v, sd):
            if si:
                ax.errorbar(xi, vi, yerr=si, color="#222222", capsize=2.5, lw=0.8)
            ax.text(xi, vi + si + 1.2, f"{vi:.1f}", ha="center", fontsize=7)
    ax.axvline(1.5, ymax=0.86, color="#777777", ls="--", lw=0.8)
    ax.set_xticks(xs); ax.set_xticklabels([g[0] for g in groups], fontsize=8); ax.set_ylabel("Accuracy (%)", fontsize=9); ax.set_ylim(0, 85)
    ax.tick_params(axis="y", labelsize=8); ax.legend(fontsize=8, loc="upper right", frameon=False, ncol=3)
    for s in ("top", "right"): ax.spines[s].set_visible(False)
    fig.tight_layout(); fig.savefig(os.path.join(FIG, "figure3_cross_text_accuracy.png"), dpi=300, facecolor="white"); plt.close(fig)

if __name__ == "__main__":
    fig1(); fig2(); fig3(); print("figures written to", FIG)
