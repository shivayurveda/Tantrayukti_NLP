#!/usr/bin/env bash
# Reproduce every table and figure of the paper from data/*.csv (about 5-10 minutes on a laptop).
set -e
cd "$(dirname "$0")"
${PYTHON:-python3} 01_main_experiments.py      > results/log_01_main.txt
${PYTHON:-python3} 02_robustness.py            > results/log_02_robustness.txt
${PYTHON:-python3} 03_multiseed_holdout.py     > results/log_03_multiseed.txt
${PYTHON:-python3} 04_nested_cv.py             > results/log_04_nested_cv.txt
${PYTHON:-python3} 05_cross_text.py            > results/log_05_cross_text.txt
${PYTHON:-python3} 06_make_figures.py          > results/log_06_figures.txt
echo "Done. Tables: results/*.csv   Figures: figures/*.png"
